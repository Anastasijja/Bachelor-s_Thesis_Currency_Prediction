# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import warnings
import itertools
import statsmodels.api as sm

from params import params


class ARIMA:

    def __init__(self, df, currency, days):
        self.df = df
        self.currency = currency
        self.days = days

    def get_ARIMA_test(self):

        warnings.filterwarnings("ignore")

        # -------------------- Автоопределение параметров для модели ARIMA -------------------------------

        # p – порядок авторегрессии (AR)
        # d – порядок интегрирования
        # q – порядок скользящего среднего (MA)

        # Предложенный ниже код пройдется по различным значениям p, d и q и подберет те, при которых AIC будет минимальным.
        # При переборе моделей из-за неточности вычислений в окне вывода будет выводиться много предупреждений,
        # поэтому будет разумно их отключить.

        n_test = self.df[self.df.index > np.datetime64(params['split_date'])].shape[0]
        print(n_test)

        data = self.df['value'][:-n_test]

        p = d = q = range(0, 2)
        pdq = list(itertools.product(p, d, q))
        seasonal_pdq = [(x[0], x[1], x[2], 12) for x in list(itertools.product(p, d, q))]

        params_list = []
        param_seasonal_list = []
        results_aic = []

        for i, param in enumerate(pdq):
            for param_seasonal in seasonal_pdq:
                mod = sm.tsa.statespace.SARIMAX(data,
                                                order=param,
                                                seasonal_order=param_seasonal,
                                                enforce_stationarity=False,
                                                enforce_invertibility=False)
                results = mod.fit()
                params_list.append(param)
                param_seasonal_list.append(param_seasonal)
                results_aic.append(results.aic)

            # form.progressBar.setValue(22 + i)


        # формируем фрейм из лучших парамтеров
        df_params = pd.DataFrame({'pdq': params_list,
                                  'seasonal': param_seasonal_list,
                                  'aic': results_aic})

        # берём значения с минимальным aic
        df_params = (df_params[df_params['aic'] == df_params['aic'].min()])

        # -------------------- Пересоберём модель с выбранными параметрами -------------------------------
        model = sm.tsa.statespace.SARIMAX(data,
                                          order=list(df_params['pdq'])[0],
                                          seasonal_order=list(df_params['seasonal'])[0],
                                          enforce_stationarity=False,
                                          enforce_invertibility=False)
        result_test = model.fit()
        last_model = sm.tsa.statespace.SARIMAX(data,
                                          order=list(df_params['pdq'])[0],
                                          seasonal_order=list(df_params['seasonal'])[0],
                                          enforce_stationarity=False,
                                          enforce_invertibility=False)
        result_test = last_model.filter(result_test.params)

        predict = result_test.get_prediction(start= int((np.datetime64(params['end_date']) -
                                                         np.datetime64(params['split_date']))/np.timedelta64(1, 'D')),
                                             end=(len(self.df)-1)).predicted_mean
        predict = pd.DataFrame(predict.values, columns=['predict'], index=predict.index)
        df = self.df.join(predict, how='outer')

        return df


    def get_ARIMA_predict(self):

        warnings.filterwarnings("ignore")

        # -------------------- Автоопределение параметров для модели ARIMA -------------------------------

        # p – порядок авторегрессии (AR)
        # d – порядок интегрирования
        # q – порядок скользящего среднего (MA)

        # Предложенный ниже код пройдется по различным значениям p, d и q и подберет те, при которых AIC будет минимальным.
        # При переборе моделей из-за неточности вычислений в окне вывода будет выводиться много предупреждений,
        # поэтому будет разумно их отключить.

        data = self.df['value']

        p = d = q = range(0, 2)
        pdq = list(itertools.product(p, d, q))
        seasonal_pdq = [(x[0], x[1], x[2], 12) for x in list(itertools.product(p, d, q))]

        params_list = []
        param_seasonal_list = []
        results_aic = []

        for i, param in enumerate(pdq):
            for param_seasonal in seasonal_pdq:
                mod = sm.tsa.statespace.SARIMAX(data,
                                                order=param,
                                                seasonal_order=param_seasonal,
                                                enforce_stationarity=False,
                                                enforce_invertibility=False)
                results = mod.fit()
                params_list.append(param)
                param_seasonal_list.append(param_seasonal)
                results_aic.append(results.aic)

            # form.progressBar.setValue(22 + i)


        # формируем фрейм из лучших парамтеров
        df_params = pd.DataFrame({'pdq': params_list,
                                  'seasonal': param_seasonal_list,
                                  'aic': results_aic})

        # берём значения с минимальным aic
        df_params = (df_params[df_params['aic'] == df_params['aic'].min()])


        # -------------------- Пересоберём модель с выбранными параметрами -------------------------------

        model = sm.tsa.statespace.SARIMAX(data,
                                          order=list(df_params['pdq'])[0],
                                          seasonal_order=list(df_params['seasonal'])[0],
                                          enforce_stationarity=False,
                                          enforce_invertibility=False)
        result_test = model.fit()

        predict = result_test.get_prediction(start= len(self.df)-self.days,
                                             end=(len(self.df) + self.days)).predicted_mean
        predict = pd.DataFrame(predict.values, columns=['predict'], index=predict.index)
        df = self.df.join(predict, how='outer')
        return df