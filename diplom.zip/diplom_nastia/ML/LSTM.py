# -*- coding: utf-8 -*-

import datetime
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from keras.preprocessing.sequence import TimeseriesGenerator
from keras.models import Sequential
from keras.layers import Dense, LSTM



from params import params


class myLSTM:

    def __init__(self, df, currency, days):
        self.df = df
        self.currency = currency
        self.days = days

    def get_LSTM_test(self):
        n_test = self.df[self.df.index > np.datetime64(params['split_date'])].shape[0]
        print(n_test)

        train = self.df[:-n_test]
        test = self.df[-n_test:]

        scaler = MinMaxScaler()
        scaler.fit(train)
        scaled_train = scaler.transform(train)
        scaled_test = scaler.transform(test)
        n_input = n_test
        n_features = 1
        generator = TimeseriesGenerator(scaled_train, scaled_train, length=n_input, batch_size=1)

        model = Sequential()
        model.add(LSTM(100, return_sequences=True, input_shape=(n_input, n_features)))
        model.add(LSTM(100, return_sequences=False))
        model.add(Dense(25))
        model.add(Dense(1))
        model.compile(optimizer='adam', loss='mean_squared_error')


        model.fit(generator, epochs=5)

        test_predictions = []
        first_eval_batch = scaled_train[-n_input:]
        current_batch = first_eval_batch.reshape((1, n_input, n_features))
        for i in range(len(test)):
            # get the prediction value for the first batch
            current_pred = model.predict(current_batch)[0]
            # append the prediction into the array
            test_predictions.append(current_pred)
            # use the prediction to update the batch and remove the first value
            current_batch = np.append(current_batch[:, 1:, :], [[current_pred]], axis=1)

        true_predictions = scaler.inverse_transform(test_predictions)
        predict = pd.DataFrame(true_predictions, columns=['predict'], index=test.index)
        df = self.df.join(predict, how='outer')
        return df


    def get_LSTM_predict(self):
        train = self.df

        scaler = MinMaxScaler()
        scaler.fit(train)
        scaled_train = scaler.transform(train)
        n_input = self.days
        n_features = 1
        generator = TimeseriesGenerator(scaled_train, scaled_train, length=n_input, batch_size=1)

        model = Sequential()
        model.add(LSTM(100, return_sequences=True, input_shape=(n_input, n_features)))
        model.add(LSTM(100, return_sequences=False))
        model.add(Dense(25))
        model.add(Dense(1))
        model.compile(optimizer='adam', loss='mean_squared_error')


        model.fit(generator, epochs=5)

        test_predictions = []
        test_index = []
        curr_index = train.index[-1] + datetime.timedelta(days=1)
        first_eval_batch = scaled_train[-n_input:]
        current_batch = first_eval_batch.reshape((1, n_input, n_features))
        for i in range(self.days):
            test_index.append(curr_index)
            curr_index += datetime.timedelta(days=1)
            # get the prediction value for the first batch
            current_pred = model.predict(current_batch)[0]
            # append the prediction into the array
            test_predictions.append(current_pred)
            # use the prediction to update the batch and remove the first value
            current_batch = np.append(current_batch[:, 1:, :], [[current_pred]], axis=1)

        true_predictions = scaler.inverse_transform(test_predictions)
        predict = pd.DataFrame(true_predictions, columns=['predict'], index=test_index)
        df = self.df.join(predict, how='outer')
        return df







