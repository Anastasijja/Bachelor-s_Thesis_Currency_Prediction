import json


with open('default_params.csv','r') as f:
    params = json.load(f)
