import tkinter as tk
import pandas as pd
import numpy as np
from params import params
from sklearn.metrics import mean_squared_error


def show_results(frame: tk.LabelFrame, df):
    for widget in frame.winfo_children():
        widget.destroy()
    if params['type'] == 'test':
        n_test = df[df.index > np.datetime64(params['split_date'])].shape[0]
        print(df[-n_test:])
        error = mean_squared_error(df.value[-n_test:], df.predict[-n_test:])
        label_res = tk.Label(frame, text=f'Error MSE: {error}')
        label_res.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

    else:
        result = df['predict'].values[-1] - df['value'].dropna().values[-1]

        if result >= 0:
            label_res = tk.Label(frame, text=f'Вы получите прибыль в размере: {result}, по паре {params["currency"]}',
                                 fg='green')
            label_res.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            label_num = tk.Label(frame, text=f'Значение в последний день:{df["predict"].values[-1]}',
                                 fg='green')
            label_num.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        else:
            label_res = tk.Label(frame, text=f'Ваш убыток составит: {result}, по паре {params["currency"]}', fg='red')
            label_res.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            label_num = tk.Label(frame, text=f'Значение в последний день:{df["predict"].values[-1]}',
                                 fg='green')
            label_num.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)



