import tkinter as tk

import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('TkAgg')

from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg,
    NavigationToolbar2Tk
)
from params import params
import prepocessing

def simple_timeseries_graphic(frame: tk.LabelFrame):
    df = pd.read_csv('./Data/current.csv', index_col=['dttm'], parse_dates=['dttm'])
    df = prepocessing.clear_prepocessing_data(df)
    figure = plt.Figure(figsize=(8, 5), dpi=100)
    ax = figure.add_subplot(111)
    ax.plot(df['value'])
    print(df)
    line = FigureCanvasTkAgg(figure, frame)
    NavigationToolbar2Tk(line, frame)
    line.get_tk_widget().pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)
    # df.plot(kind='line', legend=True, ax=ax, color='blue', fontsize=10)
    ax.set_title(params['currency'])


def plotHoltWinters(frame, df):
    """
        series - dataset with timeseries
        plot_intervals - show confidence intervals
        plot_anomalies - show anomalies
    """
    for widget in frame.winfo_children():
        widget.destroy()
    figure = plt.Figure(figsize=(8, 5), dpi=100)
    ax = figure.add_subplot(111)
    ax.plot(df.value, label="Actual")
    ax.plot(df.predict, label="Model")
    if params['type'] == 'test':
        ax.axvline(x=np.datetime64(params['split_date']),linestyle='--', color='red')
    else:
        ax.axvline(x=np.datetime64(df['value'].dropna().index[-1]), linestyle='--', color='red')

    ax.legend(loc="best", fontsize=13)
    line = FigureCanvasTkAgg(figure, frame)
    NavigationToolbar2Tk(line, frame)
    line.get_tk_widget().pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)
    ax.set_title(params['currency'])


def ARIMA_plot(frame: tk.LabelFrame, df, predict):
    for widget in frame.winfo_children():
        widget.destroy()

    figure = plt.Figure(figsize=(8, 5), dpi=100)
    ax = figure.add_subplot(111)
    ax.plot(df['value'])
    ax.plot(predict)
    line = FigureCanvasTkAgg(figure, frame)
    NavigationToolbar2Tk(line, frame)
    line.get_tk_widget().pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)
    # df.plot(kind='line', legend=True, ax=ax, color='blue', fontsize=10)
    ax.set_title(params['currency'])

def LSTM_plot(frame: tk.LabelFrame, df, predict):
    for widget in frame.winfo_children():
        widget.destroy()

    figure = plt.Figure(figsize=(8, 5), dpi=100)
    ax = figure.add_subplot(111)
    ax.plot(range(len(df)), df['value'])
    ax.plot(predict)
    line = FigureCanvasTkAgg(figure, frame)
    NavigationToolbar2Tk(line, frame)
    line.get_tk_widget().pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)
    # df.plot(kind='line', legend=True, ax=ax, color='blue', fontsize=10)
    ax.set_title(params['currency'])