import datetime


def check_date(date_str):
    try:

        datetime.date(*[int(i) for i in date_str.split('-')])
        return True
    except:
        return False


def now_date_str():
    now = datetime.datetime.now()
    return f'{now.year}-{now.month}-{now.day}'
