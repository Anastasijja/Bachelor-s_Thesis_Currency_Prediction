import tkinter as tk
import pandas as pd

import my_tools
from params import params
import parsing
import graphics
import results
import prepocessing as pr
import ExponentialSmoothing
import ARIMA
import LSTM


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title('Diploma')
#-------------------------------------Основные Фраймы-------------------------------------------------------------------
        f_settings = tk.LabelFrame(self, text='Настройки')
        f_graphics = tk.LabelFrame(self, text='Графики')
        f_results = tk.LabelFrame(self, text='Результаты')
        f_settings.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.N)
        f_graphics.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.N)
        f_results.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.N)

#--------------------------------------Фрейм Выбора---------------------------------------------------------------------
        def select_type_test():
            params['type'] = type_string.get()
            f_horizon.pack_forget()
            f_method.pack_forget()
            f_currency.pack_forget()
            f_date_predict.pack_forget()
            f_buttons.pack_forget()

            f_method.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_currency.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_date_test.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_buttons.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

            print(params['type'])

        def select_type_predict():
            params['type'] = type_string.get()

            f_method.pack_forget()
            f_currency.pack_forget()
            f_date_test.pack_forget()
            f_buttons.pack_forget()

            f_horizon.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_method.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_currency.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_date_predict.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
            f_buttons.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

            print(params['type'])

        type_string = tk.StringVar()
        type_string.set('test')
        f_type = tk.LabelFrame(f_settings, text='Выбор типа')
        f_type.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        tk.Radiobutton(f_type, text='Test',
                       command=select_type_test,
                       variable=type_string,
                       value='test').pack(anchor=tk.W)
        tk.Radiobutton(f_type, text='Predict',
                       command=select_type_predict,
                       variable=type_string,
                       value='predict').pack(anchor=tk.W)

#--------------------------------------Фрейм горизонта------------------------------------------------------------------

        horizon_number = tk.IntVar()
        f_horizon = tk.LabelFrame(f_settings, text='Горизонт предсказания')
        entry_horizon = tk.Entry(f_horizon, textvariable=horizon_number)
        entry_horizon.delete(0, tk.END)
        entry_horizon.insert(tk.END, params['horizon'])
        # f_horizon.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        entry_horizon.pack(side=tk.TOP, padx=5, pady=5)

#--------------------------------------Фрейм выбора метода--------------------------------------------------------------

        def RB_get(method):
            print(method)
            params['method'] = method_number.get()

        class RBMethod:
            def __init__(self, method, val):
                tk.Radiobutton(
                    f_method,
                    text=method.capitalize(),
                    command=lambda i=method: RB_get(i),
                    variable=method_number, value=val).pack(anchor=tk.W)

        f_method = tk.LabelFrame(f_settings, text='Выбор метода')
        f_method.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

        method_number = tk.IntVar()
        method_number.set(0)
        RBMethod('Тройное экспоненциальное сглаживание', 0)
        RBMethod('ARIMA', 1)
        RBMethod('Нейронка', 2)

#--------------------------------------Валюта---------------------------------------------------------------------------

        def RB_get_curr():
            print(f'{currency_string_1.get()}_{currency_string_2.get()}')
            if currency_string_1.get() != currency_string_2.get():
                params['currency'] = f'{currency_string_1.get()}_{currency_string_2.get()}'
            else:
                tk.messagebox.showerror(title='Error', message='Выберите разные валюты!')
            print(params)
        class RBCurrency:
            def __init__(self, currency_name, frame, cur_str):
                tk.Radiobutton(
                    frame,
                    text=currency_name.capitalize(),
                    command=RB_get_curr,
                    variable=cur_str, value=currency_name).pack(anchor=tk.W)

        f_currency = tk.LabelFrame(f_settings, text='Выбор валютной пары')
        f_currency.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        f_currency_1 = tk.LabelFrame(f_currency, text='Валюта 1')
        f_currency_1.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.N)
        f_currency_2 = tk.LabelFrame(f_currency, text='Валюта 2')
        f_currency_2.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.N)

        currency_string_1 = tk.StringVar()
        currency_string_1.set('USD')
        # RBCurrency('RUB', f_currency_1, currency_string_1)
        RBCurrency('USD', f_currency_1, currency_string_1)
        RBCurrency('EUR', f_currency_1, currency_string_1)
        RBCurrency('CNY', f_currency_1, currency_string_1)

        currency_string_2 = tk.StringVar()
        currency_string_2.set('RUB')
        RBCurrency('RUB', f_currency_2, currency_string_2)
        # RBCurrency('USD', f_currency_2, currency_string_2)
        # RBCurrency('EUR', f_currency_2, currency_string_2)
        # RBCurrency('CNY', f_currency_2, currency_string_2)

#--------------------------------------Выбор даты для теста-------------------------------------------------------------

        f_date_test = tk.LabelFrame(f_settings, text='Даты')
        f_date_test.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

        start_date = tk.StringVar()
        end_date = tk.StringVar()
        split_date = tk.StringVar()

        start_date_entry = tk.Entry(f_date_test, textvariable=start_date)
        split_data_entry = tk.Entry(f_date_test, textvariable=split_date)
        end_date_entry = tk.Entry(f_date_test, textvariable=end_date)

        start_date_entry.insert(tk.END, params['start_date'])
        split_data_entry.insert(tk.END,params['split_date'])
        end_date_entry.insert(tk.END, params['end_date'])

        start_date_entry.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        split_data_entry.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)
        end_date_entry.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

#--------------------------------------Выбор даты для предикта----------------------------------------------------------

        f_date_predict = tk.LabelFrame(f_settings, text='Даты')
        start_date_entry = tk.Entry(f_date_predict, textvariable=start_date)
        start_date_entry.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

#--------------------------------------Кнопки---------------------------------------------------------------------------

        def apply_params(param_type):
            flag_ok = True
            if param_type == 'test':
                if my_tools.check_date(start_date.get()) \
                        and my_tools.check_date(split_date.get()) \
                        and my_tools.check_date(end_date.get()):
                    params['start_date'] = start_date.get()
                    params['split_date'] = split_date.get()
                    params['end_date'] = end_date.get()
                else:
                    tk.messagebox.showerror(title='Error', message='Даты введены неверно!')
                    flag_ok = False

            else:
                try:
                    params['horizon'] = horizon_number.get()
                except:
                    tk.messagebox.showerror(title='Error', message='Не задан горизон планирования!')
                    flag_ok = False

                if my_tools.check_date(start_date.get()) \
                        and params['type'] == 'predict':
                    params['start_date'] = start_date.get()
                else:
                    tk.messagebox.showerror(title='Error', message='Даты введены неверно!')
                    flag_ok = False
            if flag_ok:
                if params['type'] == 'test':
                    df = parsing.get_data(params['currency'], params['start_date'], params['end_date'])
                    df.to_csv('./Data/current.csv', index=False)
                else:
                    df = parsing.get_data(params['currency'], params['start_date'], my_tools.now_date_str())
                    df.to_csv('./Data/current.csv', index=False)


                for widget in f_graphics.winfo_children():
                    widget.destroy()
                graphics.simple_timeseries_graphic(f_graphics)

                print(params)

        f_buttons = tk.LabelFrame(f_settings, text='Действие')
        f_buttons.pack(side=tk.TOP, padx=5, pady=5, anchor=tk.W)

        button_params = tk.Button(f_buttons, text='Ввести параметры', command=lambda: apply_params(params['type']))
        button_params.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)

        def start_engine():
            df = pr.clear_prepocessing_data(pd.read_csv('./Data/current.csv', index_col=['dttm'], parse_dates=['dttm']))
            print('Запустили вычисления')
            if params['method'] == 0 and params['type'] == 'test':
                result_df = ExponentialSmoothing.get_smoothing_model_test(df, params['split_date'])
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)
            elif params['method'] == 0 and params['type'] == 'predict':
                result_df = ExponentialSmoothing.get_smoothing_model_predict(df, params['horizon'])
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)
            elif params['method'] == 1 and params['type'] == 'test':
                result_df = ARIMA.ARIMA(df, params['currency'], params['horizon']).get_ARIMA_test()
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)
            elif params['method'] == 1 and params['type'] == 'predict':
                result_df = ARIMA.ARIMA(df, params['currency'], params['horizon']).get_ARIMA_predict()
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)
            elif params['method'] == 2 and params['type'] == 'test':
                result_df = LSTM.myLSTM(df, params['currency'], params['horizon']).get_LSTM_test()
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)
            else:
                result_df = LSTM.myLSTM(df, params['currency'], params['horizon']).get_LSTM_predict()
                graphics.plotHoltWinters(f_graphics, result_df)
                results.show_results(f_results, result_df)



        button_engine = tk.Button(f_buttons, text='Запустить вычисления', command=start_engine)
        button_engine.pack(side=tk.LEFT, padx=5, pady=5, anchor=tk.W)
