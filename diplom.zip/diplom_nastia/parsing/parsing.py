import datetime
import bs4
import re
import urllib.request
import pandas as pd

__doc__ = '''В этом модуле все посвященное парсингу,
             использовать нужно только функцию get_data(currency, moment_start, moment_end)'''

def get_data(currency, start_date, end_date):
    url = f'https://www.moex.com/export/derivatives/currency-rate.aspx?language=ru&' \
                                                                    f'currency={currency}' \
                                                                    f'&moment_start={start_date}' \
                                                                    f'&moment_end={end_date}'
    html_page = get_html(url)
    soup_object = bs4.BeautifulSoup(html_page,'html.parser')

    dttm = re.findall(r'rate moment="(.*?)"', str(soup_object))
    values = re.findall(r'value="(.*?)"', str(soup_object))

    if len(dttm) == 0:
        # переделать из принта на ловлю ошибки
        print('Ошибка с промежутком данных.')
        df = pd.DataFrame({'dttm': [], 'value': []})
        return df

    dttm, values = dttm[::-1],values[::-1]
    df = pd.DataFrame({'dttm': dttm,
                       'value': values})
    return df


def get_html(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.3'}
    reg_url = url
    req = urllib.request.Request(url=reg_url, headers=headers)
    print('Получение html')
    html = urllib.request.urlopen(req).read()
    print(f'Получил html для {url}')
    return html

