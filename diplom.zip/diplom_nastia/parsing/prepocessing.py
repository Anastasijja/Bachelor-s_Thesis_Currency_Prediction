import datetime

import pandas as pd
import numpy as np


def clear_prepocessing_data(df):
    if len(df.index.hour) % 2 == 0:
        dates = df[df.index.hour >= 18].index.date
        values = (df[df.index.hour >= 18].values + df[df.index.hour < 18].values) / 2
        df_wo_2v = pd.DataFrame(values, index=dates, columns=['value'])
    else:
        dates = df[df.index.hour >= 18].index.date
        values = (df[df.index.hour >= 18].values + df[df.index.hour < 18].values[:-1]) / 2
        df_wo_2v = pd.DataFrame(values, index=dates, columns=['value'])

    curr_day = df_wo_2v.index.values[0]
    new_indexes = np.array([curr_day])
    while curr_day < df_wo_2v.index.values[-1]:
        new_indexes = np.append(new_indexes, [curr_day + datetime.timedelta(days=1)])
        curr_day = curr_day + datetime.timedelta(days=1)

    new_values = np.array([])
    for i in range(len(new_indexes)):
        if new_indexes[i] in df_wo_2v.index:
            new_values = np.append(new_values, df_wo_2v.loc[new_indexes[i]].values)
            last_normal_value = df_wo_2v.loc[new_indexes[i]].values
        else:
            new_values = np.append(new_values, last_normal_value)

    df_clear = pd.DataFrame(new_values, index=new_indexes, columns=['value'])

    return df_clear
