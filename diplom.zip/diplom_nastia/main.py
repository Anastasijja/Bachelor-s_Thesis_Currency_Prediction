from tkinter_class import App


app = App()
app.mainloop()





